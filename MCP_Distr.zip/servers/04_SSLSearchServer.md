# SSLSearchServer — Поиск по БСП

> **ИИ-АГЕНТ**: Перед установкой ОБЯЗАТЕЛЬНО прочитай основную инструкцию `INSTALL.md` в корне папки.

## Документация

https://docs.onerpa.ru/mcp-servery-1c/servery/ssl-search-server

## Описание

Поиск по справке к Библиотеке стандартных подсистем (БСП) нужной версии. Незаменим, если конфигурация использует БСП. Не требует подготовки данных — подходит для быстрого старта.

## Параметры

| Параметр | Переменная в config.env | Обязательный |
|----------|------------------------|--------------|
| Лицензионный ключ | `LICENSE_KEY_SSL` | Да |
| Версия БСП | `SSL_VERSION` | Да (по умолчанию `3.1.11`) |
| Embedding API Base | `EMBEDDING_API_BASE` | Нет (но рекомендуется) |
| Embedding API Key | `EMBEDDING_API_KEY` | Нет (но рекомендуется) |
| Embedding Model | `EMBEDDING_MODEL` | Нет (но рекомендуется) |
| Каталог для БД | `PATH_BASES` → подкаталог `mcp_ssl` | Рекомендуется |
| Тег образа | `IMAGE_TAG` | По умолчанию `light` |
| GPU | `USE_GPU` | Нет |

## Контейнер

| Свойство | Значение |
|----------|----------|
| Образ | `comol/mcp_ssl_server` |
| Имя контейнера | `1c_ssl_mcp` |
| Порт | `8008` |

## Команда установки (PowerShell)

```powershell
docker run -d --name 1c_ssl_mcp `
  -e LICENSE_KEY="{{LICENSE_KEY_SSL}}" `
  -e SSL_VERSION="{{SSL_VERSION}}" `
  -e RESET_CACHE=false `
  -e RESET_DATABASE=false `
  -e USESSE=false `
  -e OPENAI_API_BASE="{{EMBEDDING_API_BASE}}" `
  -e OPENAI_API_KEY="{{EMBEDDING_API_KEY}}" `
  -e OPENAI_MODEL="{{EMBEDDING_MODEL}}" `
  -p 8008:8008 `
  -v "{{PATH_BASES}}/mcp_ssl:/app/chroma_db" `
  comol/mcp_ssl_server:{{IMAGE_TAG}}
```

Если `USE_GPU=true`, добавь `--gpus all` после `docker run -d`.

## Упрощённая команда (тег latest, встроенная модель)

```powershell
docker run -d --name 1c_ssl_mcp `
  -e LICENSE_KEY="{{LICENSE_KEY_SSL}}" `
  -e SSL_VERSION="{{SSL_VERSION}}" `
  -p 8008:8008 `
  -v "{{PATH_BASES}}/mcp_ssl:/app/chroma_db" `
  comol/mcp_ssl_server:latest
```

## mcp.json

```json
"1c-ssl-mcp": {
  "url": "http://localhost:8008/mcp",
  "connection_id": "1c_ssl_service_001"
}
```

## Примечания

- Рекомендуется запуск совместно с LM Studio и моделью Qwen3 Embeddings 4b/8b
- Индексация может занять несколько часов при первом запуске
- Том `mcp_ssl` рекомендуется — без него при рестарте потребуется повторная индексация
- При использовании кастомной модели рекомендуется также монтировать `/app/model_cache`

## Параметры окружения (справочно)

| Переменная | По умолчанию | Описание |
|-----------|-------------|----------|
| `SSL_VERSION` | — | Версия БСП (например `3.1.11`) |
| `RESET_CACHE` | `true` | Заново загружать модель |
| `RESET_DATABASE` | `true` | Полная переиндексация |
| `USESSE` | `false` | SSE транспорт для Legacy-клиентов |
| `OPENAI_API_BASE` | — | URL API для embedding |
| `OPENAI_API_KEY` | — | Ключ API |
| `OPENAI_MODEL` | — | Имя embedding модели |
