# CodeMetadataSearchServer — Поиск по метаданным и коду конфигурации

> **ИИ-АГЕНТ**: Перед установкой ОБЯЗАТЕЛЬНО прочитай основную инструкцию `INSTALL.md` в корне папки.

## Документация

https://docs.onerpa.ru/mcp-servery-1c/servery/code-metadata-search

## Описание

Поиск по метаданным конфигурации, справке конфигурации и паттернам кода. Индексирует текстовый отчёт и файлы выгрузки, предоставляя семантический поиск.

## Параметры

| Параметр | Переменная в config.env | Обязательный |
|----------|------------------------|--------------|
| Лицензионный ключ | `LICENSE_KEY_CODEMETADATA` | Да |
| Путь к отчёту по конфигурации | `PATH_METADATA` | Да |
| Путь к выгрузке файлов | `PATH_CODE` | Да |
| Embedding API Base | `EMBEDDING_API_BASE` | Для light-образа |
| Embedding API Key | `EMBEDDING_API_KEY` | Для light-образа |
| Embedding Model | `EMBEDDING_MODEL` | Для light-образа |
| Каталог для БД | `PATH_BASES` → подкаталог `mcp_codemetadata` | Рекомендуется |
| Тег образа | `IMAGE_TAG` | По умолчанию `light` |
| GPU | `USE_GPU` | Нет |

## Контейнер

| Свойство | Значение |
|----------|----------|
| Образ | `comol/1c_code_metadata_mcp` |
| Имя контейнера | `1c_code_metadata_mcp` |
| Порт | `8000` |

## Команда установки (PowerShell)

```powershell
docker run -d --name 1c_code_metadata_mcp `
  -e LICENSE_KEY="{{LICENSE_KEY_CODEMETADATA}}" `
  -e METADATA_PATH="/app/metadata" `
  -e CODE_PATH="/app/code" `
  -e RESET_CACHE=false `
  -e RESET_DATABASE=false `
  -e USESSE=false `
  -e OPENAI_API_BASE="{{EMBEDDING_API_BASE}}" `
  -e OPENAI_API_KEY="{{EMBEDDING_API_KEY}}" `
  -e OPENAI_MODEL="{{EMBEDDING_MODEL}}" `
  -p 8000:8000 `
  -v "{{PATH_METADATA}}:/app/metadata" `
  -v "{{PATH_CODE}}:/app/code" `
  -v "{{PATH_BASES}}/mcp_codemetadata:/app/chroma_db" `
  comol/1c_code_metadata_mcp:{{IMAGE_TAG}}
```

Если `USE_GPU=true`, добавь `--gpus all` после `docker run -d`.

## Упрощённая команда (тег latest, встроенная модель)

```powershell
docker run -d --name 1c_code_metadata_mcp `
  -e LICENSE_KEY="{{LICENSE_KEY_CODEMETADATA}}" `
  -e METADATA_PATH="/app/metadata" `
  -e CODE_PATH="/app/code" `
  -p 8000:8000 `
  -v "{{PATH_METADATA}}:/app/metadata" `
  -v "{{PATH_CODE}}:/app/code" `
  -v "{{PATH_BASES}}/mcp_codemetadata:/app/chroma_db" `
  comol/1c_code_metadata_mcp:latest
```

## mcp.json

```json
"1c-code-metadata-mcp": {
  "url": "http://localhost:8000/mcp",
  "connection_id": "1c_metadata_service_001"
}
```

## Примечания

- Индексация может занять несколько часов при первом запуске
- `PATH_METADATA` — путь к папке с текстовым отчётом из Конфигуратора (Конфигурация → Отчет по конфигурации)
- `PATH_CODE` — путь к выгрузке (Конфигурация → Выгрузить конфигурацию в файлы) или каталог EDT
- Том `mcp_codemetadata` **обязателен** — без него каждый перезапуск = повторная индексация
- При использовании кастомной модели рекомендуется также монтировать `/app/model_cache`
- В коде использован https://github.com/Dach-Coin/rlm-tools-bsl

## Параметры окружения (справочно)

| Переменная | По умолчанию | Описание |
|-----------|-------------|----------|
| `RESET_CACHE` | `true` | Заново загружать модель |
| `RESET_DATABASE` | `true` | Полная переиндексация |
| `USESSE` | `false` | SSE транспорт для Legacy-клиентов |
| `EMBEDDING_MODEL` | — | Альтернативная модель (название с HuggingFace) |
| `OPENAI_API_BASE` | — | URL API для embedding |
| `OPENAI_API_KEY` | — | Ключ API |
| `OPENAI_MODEL` | — | Имя embedding модели |
