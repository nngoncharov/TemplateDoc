# HelpSearchServer — Справка по платформе 1С

> **ИИ-АГЕНТ**: Перед установкой ОБЯЗАТЕЛЬНО прочитай основную инструкцию `INSTALL.md` в корне папки.

## Документация

https://docs.onerpa.ru/mcp-servery-1c/servery/help-search-server

## Описание

Поиск по справке платформы 1С **вашей конкретной версии**. Один из самых важных серверов — даёт ИИ доступ к актуальной документации по платформе.

## Параметры

| Параметр | Переменная в config.env | Обязательный |
|----------|------------------------|--------------|
| Лицензионный ключ | `LICENSE_KEY_HELP` | Да |
| Путь к bin платформы | `PATH_1C_BIN` | Да |
| Embedding API Base | `EMBEDDING_API_BASE` | Для light-образа |
| Embedding API Key | `EMBEDDING_API_KEY` | Для light-образа |
| Embedding Model | `EMBEDDING_MODEL` | Для light-образа |
| Каталог для БД | `PATH_BASES` → подкаталог `mcp_docs` | Рекомендуется |
| Тег образа | `IMAGE_TAG` | По умолчанию `light` |
| GPU | `USE_GPU` | Нет |

## Контейнер

| Свойство | Значение |
|----------|----------|
| Образ | `comol/1c_help_mcp` |
| Имя контейнера | `1c_help_mcp` |
| Порт | `8003` |

## Команда установки (PowerShell)

ИИ-агент подставляет значения из `config.env`. Переменные в `{{скобках}}` заменяются реальными значениями.

```powershell
docker run -d --name 1c_help_mcp `
  -e LICENSE_KEY="{{LICENSE_KEY_HELP}}" `
  -e 1C_BIN_PATH=/1c_docs `
  -e RESET_CACHE=false `
  -e RESET_DATABASE=false `
  -e USESSE=false `
  -e OPENAI_API_BASE="{{EMBEDDING_API_BASE}}" `
  -e OPENAI_API_KEY="{{EMBEDDING_API_KEY}}" `
  -e OPENAI_MODEL="{{EMBEDDING_MODEL}}" `
  -p 8003:8003 `
  -v "{{PATH_1C_BIN}}:/1c_docs" `
  -v "{{PATH_BASES}}/mcp_docs:/app/chroma_db" `
  comol/1c_help_mcp:{{IMAGE_TAG}}
```

Если `USE_GPU=true`, добавь `--gpus all` после `docker run -d`.

## Упрощённая команда (без embedding API, тег latest)

```powershell
docker run -d --name 1c_help_mcp `
  -e LICENSE_KEY="{{LICENSE_KEY_HELP}}" `
  -e 1C_BIN_PATH=/1c_docs `
  -p 8003:8003 `
  -v "{{PATH_1C_BIN}}:/1c_docs" `
  -v "{{PATH_BASES}}/mcp_docs:/app/chroma_db" `
  comol/1c_help_mcp:latest
```

## mcp.json

```json
"1c-docs-mcp": {
  "url": "http://localhost:8003/mcp",
  "connection_id": "1c_docs_service_001"
}
```

## Примечания

- Индексация справки может занять несколько часов при первом запуске
- Том `{{PATH_BASES}}/mcp_docs` сохраняет индексы между перезапусками — **не пропускай его**
- `PATH_1C_BIN` — путь к **bin** (например `C:\Program Files (x86)\1cv8\8.3.27.1936\bin`), не к корню платформы
- При использовании latest-образа без указания OPENAI_* параметров контейнер загрузит встроенную модель (нужен Интернет, до 10 ГБ диска)
- Статус индексации: `docker logs 1c_help_mcp`
- Для просмотра в реальном времени: заменить `-d` на `-it` (не закрывать терминал)

## Параметры окружения (справочно)

| Переменная | По умолчанию | Описание |
|-----------|-------------|----------|
| `RESET_CACHE` | `true` | Заново загружать модель. `false` — использовать кэшированную |
| `RESET_DATABASE` | `true` | Полная переиндексация. `false` — использовать существующую БД |
| `USESSE` | `false` | SSE транспорт. `true` — для Legacy-клиентов |
| `OPENAI_API_BASE` | — | URL API для embedding модели |
| `OPENAI_API_KEY` | — | Ключ API |
| `OPENAI_MODEL` | — | Имя embedding модели |
