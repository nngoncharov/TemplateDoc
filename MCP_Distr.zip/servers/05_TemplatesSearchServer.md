# TemplatesSearchServer — Шаблоны кода 1С

> **ИИ-АГЕНТ**: Перед установкой ОБЯЗАТЕЛЬНО прочитай основную инструкцию `INSTALL.md` в корне папки.

## Документация

https://docs.onerpa.ru/mcp-servery-1c/servery/templates-search-server

## Описание

Поиск по публично доступным шаблонам кода 1С. В сотни раз эффективнее веб-поиска. Можно и **нужно** добавлять свои шаблоны через веб-интерфейс. Не требует подготовки данных — подходит для быстрого старта.

## Параметры

| Параметр | Переменная в config.env | Обязательный |
|----------|------------------------|--------------|
| Лицензионный ключ | `LICENSE_KEY_TEMPLATES` | Да |
| Embedding API Base | `EMBEDDING_API_BASE` | Для light-образа |
| Embedding API Key | `EMBEDDING_API_KEY` | Для light-образа |
| Embedding Model | `EMBEDDING_MODEL` | Для light-образа |
| Каталог для БД | `PATH_BASES` → подкаталог `mcp_templates` | Рекомендуется |
| Тег образа | `IMAGE_TAG` | По умолчанию `light` |
| GPU | `USE_GPU` | Нет |

## Контейнер

| Свойство | Значение |
|----------|----------|
| Образ | `comol/template-search-mcp` |
| Имя контейнера | `1c_templates_mcp` |
| Порт | `8004` |

## Команда установки (PowerShell)

```powershell
docker run -d --name 1c_templates_mcp `
  -e LICENSE_KEY="{{LICENSE_KEY_TEMPLATES}}" `
  -e RESET_CACHE=false `
  -e RESET_DATABASE=false `
  -e USESSE=false `
  -e OPENAI_API_BASE="{{EMBEDDING_API_BASE}}" `
  -e OPENAI_API_KEY="{{EMBEDDING_API_KEY}}" `
  -e OPENAI_MODEL="{{EMBEDDING_MODEL}}" `
  -p 8004:8004 `
  -v "{{PATH_BASES}}/mcp_templates:/app/chroma_db" `
  comol/template-search-mcp:{{IMAGE_TAG}}
```

Если `USE_GPU=true`, добавь `--gpus all` после `docker run -d`.

## Упрощённая команда (тег latest, встроенная модель)

```powershell
docker run -d --name 1c_templates_mcp `
  -e LICENSE_KEY="{{LICENSE_KEY_TEMPLATES}}" `
  -p 8004:8004 `
  -v "{{PATH_BASES}}/mcp_templates:/app/chroma_db" `
  comol/template-search-mcp:latest
```

## mcp.json

```json
"1c-templates-mcp": {
  "url": "http://localhost:8004/mcp",
  "connection_id": "1c_templates_service_001"
}
```

## Веб-интерфейс для шаблонов

После запуска доступен интерфейс для просмотра и редактирования шаблонов:

**http://localhost:8004/extend/**

Здесь можно добавлять собственные шаблоны кода.

## Примечания

- Для этого сервиса переиндексация при старте — нормальное решение, том подключать не обязательно (но рекомендуется)
- При подготовке использованы шаблоны с https://fastcode.im/Templates
- При использовании кастомной модели рекомендуется также монтировать `/app/model_cache`

## Параметры окружения (справочно)

| Переменная | По умолчанию | Описание |
|-----------|-------------|----------|
| `RESET_CACHE` | `true` | Заново загружать модель |
| `RESET_DATABASE` | `true` | Полная переиндексация |
| `USESSE` | `false` | SSE транспорт для Legacy-клиентов |
| `EMBEDDING_MODEL` | — | Альтернативная модель (например `ai-forever/FRIDA`) |
| `OPENAI_API_BASE` | — | URL API для embedding |
| `OPENAI_API_KEY` | — | Ключ API |
| `OPENAI_MODEL` | — | Имя embedding модели |
