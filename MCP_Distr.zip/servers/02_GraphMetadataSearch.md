# GraphMetadataSearch — Графовый поиск по метаданным

> **ИИ-АГЕНТ**: Перед установкой ОБЯЗАТЕЛЬНО прочитай основную инструкцию `INSTALL.md` в корне папки.

## Документация

https://docs.onerpa.ru/mcp-servery-1c/servery/graph-metadata-search

## Описание

Графовый поиск связей между объектами метаданных конфигурации 1С. Использует Neo4j для хранения графа и семантический поиск. При прочих равных **предпочтительнее** CodeMetadataSearchServer — лучше понимает связи между объектами.

## Особенность

Этот сервер запускается через **docker-compose** (а не через `docker run`), так как включает два контейнера: Neo4j + MCP-приложение. Файлы находятся в папке `Graph_metadata_search/` в корне MCP_Distr.

## Параметры

| Параметр | Переменная в config.env | Обязательный |
|----------|------------------------|--------------|
| Лицензионный ключ | `LICENSE_KEY_GRAPH` | Да |
| Путь к отчёту по конфигурации | `PATH_METADATA` | Да |
| Путь к выгрузке файлов | `PATH_CODE` | Нет (обогащает метаданные) |
| Embedding API Base | `EMBEDDING_API_BASE` | Рекомендуется |
| Embedding API Key | `EMBEDDING_API_KEY` | Рекомендуется |
| Embedding Model | `EMBEDDING_MODEL` | Рекомендуется |
| Chat API Base | `CHAT_API_BASE` | Для бизнес-описаний |
| Chat API Key | `CHAT_API_KEY` (если OpenRouter — можно использовать тот же ключ что EMBEDDING_API_KEY) | Для бизнес-описаний |
| Chat Model | `CHAT_MODEL` (по умолчанию `qwen/qwen3-235b-a22b`) | Для бизнес-описаний |
| Тег образа | `IMAGE_TAG` | По умолчанию `latest` |

## Контейнеры

| Свойство | Значение |
|----------|----------|
| Образ MCP | `comol/1c_graph_metadata` |
| Образ Neo4j | `neo4j:latest` |
| Имя MCP-контейнера | `1c_graph_metadata` |
| Имя Neo4j-контейнера | `neo4j` |
| Порт MCP | `8006` |
| Порты Neo4j | `7474` (web), `7687` (bolt) |

## Установка

### 1. Обновить .env файл

ИИ-агент должен заполнить файл `Graph_metadata_search/.env` значениями из `config.env`:

| Поле в .env | Значение из config.env |
|-------------|----------------------|
| `LICENSE_KEY` | `LICENSE_KEY_GRAPH` |
| `METADATA_HOST_PATH` | `PATH_METADATA` |
| `METADATA_FILES_HOST_PATH` | `PATH_CODE` (если заполнен) |
| `OPENAI_API_KEY` | `CHAT_API_KEY` |
| `OPENAI_API_BASE` | `CHAT_API_BASE` |
| `OPENAI_MODEL` | `CHAT_MODEL` |
| `OPENAI_EMBEDDING_API_KEY` | `EMBEDDING_API_KEY` |
| `OPENAI_EMBEDDING_API_BASE` | `EMBEDDING_API_BASE` |
| `OPENAI_EMBEDDING_MODEL` | `EMBEDDING_MODEL` |
| `IMAGE_TAG` | `IMAGE_TAG` |

**Остальные параметры** в `.env` оставь по умолчанию (для простого режима) или обсуди с пользователем (для детального).

### 2. Запустить

```powershell
cd Graph_metadata_search
docker-compose up -d
```

### 3. Проверить

```powershell
docker logs 1c_graph_metadata
docker logs neo4j
```

## mcp.json

```json
"1c-graph-metadata-mcp": {
  "url": "http://localhost:8006/mcp",
  "connection_id": "1c_graph_metadata_001"
}
```

## Обновление

Обновление отличается от других серверов:
1. `cd Graph_metadata_search && docker-compose down`
2. При необходимости переименовать Docker volumes:
   ```
   docker volume ls --filter "name=graph_metadata"
   ```
3. Обновить `.env` из `config.env`
4. `docker-compose pull && docker-compose up -d`

## Примечания

- Индексация может занять значительное время
- Данные Neo4j сохраняются в Docker volume автоматически
- Если `USE_GPU=true`, раскомментируй секцию `deploy.resources` с GPU в `docker-compose.yml`
- Параметр `CALCULATE_BUSINESS_INFO=true` включает автогенерацию бизнес-описаний (требует Chat API)
- Подробное описание ВСЕХ параметров — в файле `Graph_metadata_search/.env`

## Ключевые параметры .env (справочно)

| Переменная | По умолчанию | Описание |
|-----------|-------------|----------|
| `RESET_DATABASE` | `false` | Сброс векторных индексов |
| `CALCULATE_BUSINESS_INFO` | `false` | Генерация AI-описаний объектов |
| `ENABLE_BUSINESS_SEARCH` | `true` | Семантический поиск по описаниям |
| `ENABLE_CODE_SEARCH` | `true` | Поиск по BSL-коду |
| `LOAD_BSL_SIGNATURES` | `true` | Граф вызовов процедур/функций |
| `TEMPLATE_MODE_ENABLED` | `true` | Шаблонные JSON-запросы |
| `BACKGROUND_POST_INDEXING` | `true` | Фоновая индексация (сервер стартует сразу) |
| `MCP_USE_SSE` | `false` | SSE транспорт для Legacy-клиентов |
