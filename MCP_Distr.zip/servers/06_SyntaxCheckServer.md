# SyntaxCheckServer — Проверка синтаксиса BSL

> **ИИ-АГЕНТ**: Перед установкой ОБЯЗАТЕЛЬНО прочитай основную инструкцию `INSTALL.md` в корне папки.

## Документация

https://docs.onerpa.ru/mcp-servery-1c/servery/syntax-check-server

## Описание

Проверка синтаксиса кода 1С через BSL Language Server. Самый простой в установке сервер — не требует никаких данных и настроек, только лицензионный ключ.

## Параметры

| Параметр | Переменная в config.env | Обязательный |
|----------|------------------------|--------------|
| Лицензионный ключ | `LICENSE_KEY_SYNTAX` | Да |
| GPU | `USE_GPU` | Нет |

## Контейнер

| Свойство | Значение |
|----------|----------|
| Образ | `comol/1c_syntaxcheck_mcp` |
| Имя контейнера | `1c_syntaxcheck_mcp` |
| Порт | `8002` |

## Команда установки (PowerShell)

```powershell
docker run -d --name 1c_syntaxcheck_mcp `
  -e LICENSE_KEY="{{LICENSE_KEY_SYNTAX}}" `
  -e USESSE=false `
  -p 8002:8002 `
  comol/1c_syntaxcheck_mcp:latest
```

Если `USE_GPU=true`, добавь `--gpus all` после `docker run -d`.

## mcp.json

```json
"1c-syntax-checker-mcp": {
  "url": "http://localhost:8002/mcp",
  "connection_id": "1c_lsp_service_001"
}
```

## Примечания

- Не требует индексации — запускается мгновенно
- Не требует embedding модели
- Для этого сервера всегда используется тег `latest`
- Параметр `USESSE=true` нужен только для Legacy-клиентов

## Параметры окружения (справочно)

| Переменная | По умолчанию | Описание |
|-----------|-------------|----------|
| `USESSE` | `false` | SSE транспорт для Legacy-клиентов |
